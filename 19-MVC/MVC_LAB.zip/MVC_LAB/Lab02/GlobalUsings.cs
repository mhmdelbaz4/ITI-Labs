﻿global using Microsoft.EntityFrameworkCore;
global using System.ComponentModel.DataAnnotations;
global using System.ComponentModel.DataAnnotations.Schema;
global using Microsoft.AspNetCore.Mvc;
global using Lab02.Models;
global using Lab02.ViewModels;
global using Lab02;
global using Lab02.Repos;
global using Microsoft.AspNetCore.Mvc.Rendering;

