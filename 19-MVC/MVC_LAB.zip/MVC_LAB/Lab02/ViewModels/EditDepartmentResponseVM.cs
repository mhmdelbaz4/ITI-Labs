﻿namespace Lab02.ViewModels;

public class EditDepartmentResponseVM
{
    public Department Department { get; set; }
}
